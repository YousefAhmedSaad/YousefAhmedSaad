// udacity project by Yousef Ahmed //

//sourced i got help with { Elzero wep school(YT channel) , W3schools (wepsite)}

// define variables
let navigation = document.getElementById('ul1');
let sections = document.querySelectorAll('section');

// main function
onscroll = function(){
    let scrollPosition = this.document.documentElement.scrollTop;
    sections.forEach((section) => {
        if(
            // to make to scroll begin before the end of the section :)
            scrollPosition >= section.offsetTop - section.offsetHeight *0.15 &&
            scrollPosition <
              section.offsetTop + section.offsetHeight - section.offsetHeight * 0.15
        ){
            // giving id for the activated class
            let currentId = section.attributes.id.value;
            removeAllActiveClasses();
            addActiveClass(currentId);
        }
    });
};  
// nav , listitem builder
let navBuilder = () =>{
    let navUI ='';
    sections.forEach(section => {
        let sectionID = section.id;
        let sectionDataNav = section.dataset.nav;
        // creat list item
        navUI += `<li><a class="li1" href="#${sectionID}">${sectionDataNav}</a></li>`;
    });
    navigation.innerHTML = navUI;
};
navBuilder();

// remove active class
let removeAllActiveClasses = function () {
    document.querySelectorAll("nav a").forEach((el) => {
        el.classList.remove("active");
    });
};

//add active class
let addActiveClass = function (id) {
    let selector = `nav a[href="#${id}"]`;
    document.querySelector(selector).classList.add("active");
};

//navlinlks
let navLinks = document.querySelectorAll("nav a");
navLinks.forEach((link) => {
    link.addEventListener("click", (e) => {
        e.preventDefault();
        let currentId = e.target.attributes.href.value;
        let section = document.querySelector(currentId);
        let sectionPos = section.offsetTop;
        // smooth scrolling
        window.scroll({
            top: sectionPos,
            behavior: "smooth",
        });
    });
});
//end :)

