
## Project Summary
* creat 4 sections
* give some properties with css 
* creat a list navbar with listitem with JavaScript
* when add a new section in html file it will be added in the navbar
* adding active section
* navbar is responsive on mobile screen


## Please note 
* i made the past notes of this project 
* i made the entire project

## sources i got help with
https://www.w3schools.com/
https://youtube.com/c/ElzeroInfo

## MY GITHUB
https://github.com/YousefAhmedSaad/YousefAhmedSaad.git





